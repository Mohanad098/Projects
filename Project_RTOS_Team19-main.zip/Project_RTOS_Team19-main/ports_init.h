#ifndef PORTS_INIT_H_
#define PORTS_INIT_H_

//Function prototype for initialize the hardware of Port-D
void PortD_Init(void);

//Function prototype for initialize the hardware of Port-E
void PortE_Init(void);
	
//Function prototype for initialize hardware of Port-F
void PortF_Init(void);
	
#endif 