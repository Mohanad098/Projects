/*
 * timer_priv.h
 *
 *  Created on: Sep 12, 2023
 *      Author: ahmed essam mohamed
 */

#ifndef MTIM_CONFIG_H_
#define MTIM_CONFIG_H_

#define ENABLE 1
#define DISABLE 0

#define TIMER2 ENABLE

#define TIMER3 ENABLE

#define TIMER4 ENABLE

#define TIMER5 DISABLE

#endif /* MTIM_CONFIG_H_ */
